export interface Team {
  teamId: number;
  teamName: string;
  teamSName: string;
  imageId: number;
}

export interface Player{
    
}

export type MatchOccurrence = "live" | "recent" | "upcoming";