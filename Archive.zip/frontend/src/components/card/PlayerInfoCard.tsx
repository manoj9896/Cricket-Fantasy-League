import React from "react";

function PlayerInfoCard() {
  return <div>PlayerInfoCard</div>;
}

export default PlayerInfoCard;
